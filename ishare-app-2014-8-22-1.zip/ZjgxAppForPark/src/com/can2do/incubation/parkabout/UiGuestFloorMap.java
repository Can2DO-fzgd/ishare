package com.can2do.incubation.parkabout;
import com.can2do.incubation.guest.ui.UiGuestContentUsList;
import com.can2do.ishare.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

public class UiGuestFloorMap extends Activity {
	private Button goBack;
	private Spinner mySpinner;
	private ImageView myImage;
	private float mx,my;
	int [] imageIds=new int[]{
		R.drawable.floor_map_1,R.drawable.floor_map_2,
		R.drawable.floor_map_3,R.drawable.floor_map_4,
		R.drawable.floor_map_5};
	String[] floors=new String[]{"一楼平面图","二楼平面图","三楼平面图","四楼平面图","五楼平面图"};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_floor_map);
		//SysApplication.getInstance().addActivity(this);
		goBack = (Button)findViewById(R.id.goBack);
		myImage=(ImageView)findViewById(R.id.myImage);
        goBack.setOnClickListener(new Button.OnClickListener(){            
			@Override
			public void onClick(View v){                
                Intent intent = new Intent (UiGuestFloorMap.this,UiGuestContentUsList.class);
                startActivity(intent);
                finish();
            }  
        });  	
		ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,floors);
		mySpinner = (Spinner)findViewById(R.id.spinner);
		//为Spinner设置Adapter
		mySpinner.setAdapter(adapter);
		//添加选中事件监听器
		mySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int position, long id) {
				myImage.setImageResource(imageIds[position]);				
			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				myImage.setImageResource(imageIds[0]);				
			}			
		});	
		myImage.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				float curX,curY;
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					mx=event.getX();
					my=event.getY();
					break;
				case MotionEvent.ACTION_MOVE:
					curX=event.getX();
					curY=event.getY();
					myImage.scrollBy((int)(mx-curX), (int)(my-curY));
					mx=curX;
					my=curY;
					break;
				case MotionEvent.ACTION_UP:
					curX=event.getX();
					curY=event.getY();
					myImage.scrollBy((int)(mx-curX), (int)(my-curY));
					break;

				default:
					break;
				}
				return true;
			}
		});
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(UiGuestFloorMap.this,UiGuestContentUsList.class);
			startActivity(intent);
			this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}

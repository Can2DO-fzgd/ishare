﻿package com.can2do.incubation.phone;

import com.can2do.incubation.sqlite.DBHandler;
import com.can2do.incubation.sqlite.MyDatabaseHelper;
import com.can2do.incubation.ui.UiContentUs;
import com.can2do.ishare.R;
//import com.zjgx.app.ui.SysApplication;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import android.app.AlertDialog;
import android.app.ExpandableListActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleExpandableListAdapter;

public class UiPhoneList extends ExpandableListActivity {
	
	public static MyDatabaseHelper myHelper;
	private EditText keyword;
	private Button query;
	DBHandler dbHandler = new DBHandler();
	SQLiteDatabase db;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_phone_list);
		//SysApplication.getInstance().addActivity(this);
		myHelper = new MyDatabaseHelper(this, "phone.db", null, 1);	
		db = myHelper.getReadableDatabase();
		String sql = "select distinct type from phone_tb";
		ArrayList<String> type = dbHandler.getType(db, sql);
		ArrayList<Map<String, String>> groups = new ArrayList<Map<String, String>>();
		ArrayList<List<Map<String, String>>> children = new ArrayList<List<Map<String, String>>>();
		for (String str : type) {
			Map<String, String> item = new HashMap<String, String>();
			item.put("group", str);
			groups.add(item);
			ArrayList<Map<String, String>> child = dbHandler.getData(db,
					"select name,phone from phone_tb where type=?", new String[]{str});
			System.out.println(child);
			children.add(child);
		}

		SimpleExpandableListAdapter simpleExpandListAdapter = new SimpleExpandableListAdapter(
				this, groups, R.layout.ui_phone_list_group, new String[] { "group" },
				new int[] { R.id.group }, children, R.layout.ui_phone_list_child,
				new String[] { "name", "phone" }, new int[] { R.id.name,
						R.id.phone });
		setListAdapter(simpleExpandListAdapter);
		keyword = (EditText) findViewById(R.id.keyword);
		query = (Button) findViewById(R.id.query);
		query.setOnClickListener(new OnClickListener() {
			String sql = "select name,phone from phone_tb where keyword like ?";

			@Override
			public void onClick(View v) {
				ArrayList<Map<String, String>> phoneList= dbHandler.getData(db, sql,
						new String[] { "%" + keyword.getText().toString() + "%"});
				Intent intent=new Intent(UiPhoneList.this,UiResult.class);
				Bundle bundle=new Bundle();
				bundle.putSerializable("result", phoneList);
				System.out.println("phoneList="+phoneList);
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.phone_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.addphone:
			Intent intent = new Intent(UiPhoneList.this,
					UiAddPhone.class);
			startActivity(intent);
			break;
		case R.id.menu_about:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle(R.string.menu_app_about);
			String appName = this.getString(R.string.app_name);
			String appVersion = this.getString(R.string.app_version);
			String appAbout = this.getString(R.string.app_about);
			builder.setMessage(appName + " " + appVersion + appAbout);
			builder.setIcon(R.drawable.icon);
			builder.setPositiveButton(R.string.btn_cancel, null);
			builder.show();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(UiPhoneList.this,UiContentUs.class);
			startActivity(intent);
			this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
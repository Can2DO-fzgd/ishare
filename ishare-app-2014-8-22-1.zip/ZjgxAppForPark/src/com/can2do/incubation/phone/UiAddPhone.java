﻿package com.can2do.incubation.phone;


import com.can2do.incubation.sqlite.DBHandler;
import com.can2do.ishare.R;
//import com.zjgx.app.ui.SysApplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UiAddPhone extends Activity {
	private Button submit, reset;
	private EditText name, phone, type, keyword;
	private SQLiteDatabase db = UiPhoneList.myHelper
			.getReadableDatabase();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_add_phone);
		//SysApplication.getInstance().addActivity(this);
		submit = (Button) findViewById(R.id.submit);
		reset = (Button) findViewById(R.id.reset);
		name = (EditText) findViewById(R.id.name);
		phone = (EditText) findViewById(R.id.phone);
		type = (EditText) findViewById(R.id.type);
		keyword = (EditText) findViewById(R.id.keyword);
		myOnclickListener myOnclickListener = new myOnclickListener();
		submit.setOnClickListener(myOnclickListener);
		reset.setOnClickListener(myOnclickListener);
	}

	@SuppressLint("ShowToast")
	private class myOnclickListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.submit:
				DBHandler dbHandler = new DBHandler();
				String sql = "insert into phone_tb values(null,?,?,?,?)";
				String keywordStr = keyword.getText().toString();
				if (keywordStr == null || "".equals(keywordStr)) {
					keywordStr = name.getText().toString()
							+ phone.getText().toString();
				}
				dbHandler.insert(db, sql, new String[] {
						name.getText().toString(), phone.getText().toString(),
						type.getText().toString(), keywordStr });
				Toast.makeText(UiAddPhone.this, "号码添加成功！", 1000).show();
				Intent intent=new Intent(UiAddPhone.this,UiPhoneList.class);
				startActivity(intent);
				finish();
				break;
			case R.id.reset:
				name.setText("");
				phone.setText("");
				type.setText("");
				keyword.setText("");
				break;
			default:
				break;
			}
		}
	}
}
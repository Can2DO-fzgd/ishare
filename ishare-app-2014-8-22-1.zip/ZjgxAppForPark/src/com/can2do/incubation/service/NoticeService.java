package com.can2do.incubation.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseService;
import com.can2do.incubation.base.C;
import com.can2do.incubation.model.Notice;
import com.can2do.incubation.ui.UiNewZixun;
import com.can2do.incubation.ui.UiNewsall;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.IBinder;

public class NoticeService extends BaseService {

	private static final int ID = 1000;
	private static final String NAME = NoticeService.class.getName();
	
	// Notification manager to displaying arrived push notifications 
	private NotificationManager	notiManager;
	
	// Thread Pool Executors
	private ExecutorService execService;
	
	// Loop getting notice
	private boolean runLoop = true;
	
	@Override
	public IBinder onBind(Intent intent) {
		return super.onBind(intent);
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		notiManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		execService = Executors.newSingleThreadExecutor();
	}
	
	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		if (intent.getAction().equals(NAME + BaseService.ACTION_START)) {
			startService();
		}
	}
	
	@Override
	public void onDestroy() {
		runLoop = false;
	}
	
	public void startService () {
		execService.execute(new Runnable(){
			@Override
			public void run() {
				while (runLoop) {
					try {
						// get notice
						doTaskAsync(C.task.notice, C.api.notice);
						// sleep 30 seconds
						Thread.sleep(30 * 1000L);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}
	
	@Override
	public void onTaskComplete (int taskId, BaseMessage message) {
		try {
			Notice notice = (Notice) message.getResult("Notice");
			String friendscount =notice.getFriendscount();
			String newsnoticecount =notice.getNewsnoticecount();
			int i = Integer.parseInt(friendscount); 
			int j = Integer.parseInt(newsnoticecount);

			if (i == 0 && j == 0){//not notice
				showNotification3(notice.getMessage());
			} else if(i>0 && j == 0){//add fas notice
				showNotification(notice.getMessage());
			} else if(i == 0 && j>0){//new news notice
				showNotification1(notice.getMessage());
			} else {//add fas and new news notice
				showNotification2(notice.getMessage());
			}
		} catch (Exception e) {
		}
	}
	//add fas  notice
	private void showNotification(String text) {
		try {
			Notification n = new Notification();
			n.flags |= Notification.FLAG_SHOW_LIGHTS;
	      	n.flags |= Notification.FLAG_AUTO_CANCEL;
	        n.defaults = Notification.DEFAULT_ALL;
			n.icon = com.can2do.ishare.R.drawable.icon;
			n.when = System.currentTimeMillis();
			// Simply open the parent activity
			PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, UiNewsall.class), 0);
			// Change the name of the notification here
			n.setLatestEventInfo(this, "移动园区关注信息通知", text, pi);
			// show notification
			notiManager.notify(ID, n);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//new news notice
	private void showNotification1(String text) {
		try {
			Notification n = new Notification();
			n.flags |= Notification.FLAG_SHOW_LIGHTS;
	      	n.flags |= Notification.FLAG_AUTO_CANCEL;
	        n.defaults = Notification.DEFAULT_ALL;
			n.icon = com.can2do.ishare.R.drawable.icon;
			n.when = System.currentTimeMillis();
			// Simply open the parent activity
			PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, UiNewZixun.class), 0);
			// Change the name of the notification here
			n.setLatestEventInfo(this, "移动园区最新资讯通知", text, pi);
			// show notification
			notiManager.notify(ID, n);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//add fas and new news notice
	private void showNotification2(String text) {
		try {
			Notification n = new Notification();
			n.flags |= Notification.FLAG_SHOW_LIGHTS;
	      	n.flags |= Notification.FLAG_AUTO_CANCEL;
	        n.defaults = Notification.DEFAULT_ALL;
			n.icon = com.can2do.ishare.R.drawable.icon;
			n.when = System.currentTimeMillis();
			// Simply open the parent activity
			PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, UiNewZixun.class), 0);
			// Change the name of the notification here
			n.setLatestEventInfo(this, "移动园区信息通知", text, pi);
			// show notification
			notiManager.notify(ID, n);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//not notice
	private void showNotification3(String text) {
		try {
			Notification n = new Notification();
			n.flags |= Notification.FLAG_SHOW_LIGHTS;
	      	n.flags |= Notification.FLAG_AUTO_CANCEL;
	        n.defaults = Notification.DEFAULT_ALL;
			n.icon = com.can2do.ishare.R.drawable.icon;
			n.when = System.currentTimeMillis();
			// Simply open the parent activity
			PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, UiNewZixun.class), 0);
			// Change the name of the notification here
			n.setLatestEventInfo(this, "移动园区信息通知提示！", text, pi);
			// show notification
			notiManager.notify(ID, n);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
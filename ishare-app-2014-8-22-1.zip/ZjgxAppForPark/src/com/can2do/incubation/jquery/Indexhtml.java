package com.can2do.incubation.jquery;

import org.apache.cordova.DroidGap;
import android.os.Bundle;

public class Indexhtml extends DroidGap {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.loadUrl("file:///android_asset/www/demo/gallery/index.html");
    }
}
package com.can2do.incubation.guest.base;

public final class GuestC {

	////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static final class web {
		//紫金高新网址
		public static final String base				= "http://www.njibi.com.cn";
		//特区公告
		public static final String news1			= base + "/more1_1.html";
		//特区新闻
		public static final String news2			= base + "/more1_2.html";
		//政策公开
		public static final String news3			= base + "/more1_12.html";
		//发文公开
		public static final String news4			= base + "/more1_13.html";
		//图片新闻
		public static final String news5			= base + "/more1_11.html";
		//特区荣誉
		public static final String news6			= base + "/more1_5.html";
		//媒体报道
		public static final String news7			= base + "/more1_8.html";
		//企业通道
		public static final String news8			= base + "/toLogin1.action";
		//企业走廊
		public static final String news9			= base + "/more1_17.html";
		//视频新闻
		public static final String news10			= base + "/more1_10.html";
		//政策解读
		public static final String news12			= base + "/more1_7.html";
		//材料阅读
		public static final String news13			= base + "/more1_6.html";
		//优惠政策
		public static final String news14			= base + "/more1_14.html";
		//人才政策
		public static final String news15			= base + "/more1_15.html";
		//产品走廊
		public static final String products			= base + "/more1_18.html";
		//园区论坛
		public static final String fashion4			= base + "/bbs/forum.php?mobile=yes";
		//在线场地管理
		public static final String content2			= base + "/togardenmobile.html";
		//在线留言
		public static final String messagemobile	= base + "/messagemobile.html";
		//部门联系
		public static final String phone			= base + "/contactusmobile.html";
		//公共服务走廊
		public static final String news11			= base + "/servicemobile.html";
		
		//////////////////////////////////////////////////////////////////////
		//紫金高新其他特色功能
		public static final String fashion			= "http://map.njibi.com.cn";
		//地图
		public static final String gomap			= fashion + "/gomap.php";
		//会议预订
		public static final String fashion2			= fashion + "/2014/meetmagan.html";
		//关于我们
		public static final String content1			= fashion + "/2014/aboutus.html";
		//微博平台
		public static final String mysite1			= fashion + "/2014/weibo.html";
		//微信平台
		public static final String mysite2			= fashion + "/2014/weixin.html";
		
		///////////////////////////////////////////////////////////////////////
		//园区邮箱
		public static final String fashion3			= "http://ym.163.com";
	}
}
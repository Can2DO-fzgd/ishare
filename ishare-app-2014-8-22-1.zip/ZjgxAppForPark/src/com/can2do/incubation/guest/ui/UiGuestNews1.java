//package com.zjgx.app.guest.ui;
//
//import com.zjgx.app.R;
//import com.zjgx.app.base.LJWebView;
//import com.zjgx.app.guest.base.BaseGuestUiWeb;
//import com.zjgx.app.guest.base.GuestC;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.webkit.WebSettings;
//import android.webkit.WebView;
//import android.webkit.WebViewClient;
//import android.widget.TextView;
//
//
//public class UiGuestNews1 extends BaseGuestUiWeb{
//
//	private LJWebView mLJWebView = null;
//
//	@Override
//	public void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.ui_fragmentweb1);
//		
//		mLJWebView = (LJWebView) findViewById(R.id.web);
//		mLJWebView.setProgressStyle(LJWebView.Circle);
//		mLJWebView.setBarHeight(8);
//		mLJWebView.setClickable(true);
//		mLJWebView.setUseWideViewPort(true);
//		//mLJWebView.setSupportZoom(true);
//		//mLJWebView.setBuiltInZoomControls(true);
//		mLJWebView.setJavaScriptEnabled(true);
//		mLJWebView.setCacheMode(WebSettings.LOAD_NO_CACHE);		
//		mLJWebView.setWebViewClient(new WebViewClient() {
//
//			@Override
//			public boolean shouldOverrideUrlLoading(WebView view, String url) {
//				System.out.println("跳的URL =" + url);
//				view.loadUrl(url);
//				return true;
//			}
//		});
//
//		mLJWebView.loadUrl(GuestC.web.news1);
//
//	}
//
//}

package com.can2do.incubation.guest.ui;
//特区公告
import android.content.Intent;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.can2do.incubation.guest.base.BaseGuestUiWeb;
import com.can2do.incubation.guest.base.GuestC;
import com.can2do.ishare.R;

public class UiGuestNews1 extends BaseGuestUiWeb {
	
	private WebView mWebViewMap;
	
	private long index_exitTime;
			
	@Override
	public void onStart() {
		super.onStart();
		
		setContentView(R.layout.guest_main_layout);
		
		mWebViewMap = (WebView) findViewById(R.id.web_map);
		mWebViewMap.getSettings().setJavaScriptEnabled(true);
		mWebViewMap.setWebViewClient(new WebViewClient(){
		
		});
		mWebViewMap.loadUrl(GuestC.web.news1);
		this.setWebView(mWebViewMap);
		this.startWebView();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebViewMap.canGoBack()) {
			mWebViewMap.goBack();
			return true;
			}else if (keyCode == KeyEvent.KEYCODE_BACK) {
				getOut();
				return true;
				} else {
					return super.onKeyDown(keyCode, event);
					}
		}
	
	protected void getOut() {
		long nowTime = System.currentTimeMillis();
		if (nowTime - index_exitTime > 3000) {
			Toast toast = Toast.makeText(this, "再按一次关闭特区公告窗口！", Toast.LENGTH_SHORT);
			toast.show();
			index_exitTime = nowTime;
		} else {
			Intent intent = new Intent(UiGuestNews1.this,UiGuestZixunList.class);
			startActivity(intent);
			this.finish();
		}
	}
}
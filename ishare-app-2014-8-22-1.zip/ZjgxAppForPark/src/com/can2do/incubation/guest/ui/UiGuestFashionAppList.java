package com.can2do.incubation.guest.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;

import com.can2do.incubation.guest.base.BaseGuestUiAuth;
import com.can2do.ishare.R;

public class UiGuestFashionAppList extends BaseGuestUiAuth {

	private GridView gridview;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_guest_zixun_list);

		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_2);
		ib.setImageResource(R.drawable.guest_top2_2);

		List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
		
		//types1-微博平台
		Map<String, Object> item1 = new HashMap<String, Object>();
		item1.put("imageItem", R.drawable.fashionapp_types1);
		item1.put("textItem", "");
		items.add(item1);
				
		//types2-微信平台
		Map<String, Object> item2 = new HashMap<String, Object>();
		item2.put("imageItem", R.drawable.fashionapp_types2);
		item2.put("textItem", "");
		items.add(item2);
				
		//types3-园区论坛
		Map<String, Object> item3 = new HashMap<String, Object>();
		item3.put("imageItem", R.drawable.fashionapp_types3);
		item3.put("textItem", "");
		items.add(item3);
				
		//types4-园区地图
		Map<String, Object> item4 = new HashMap<String, Object>();
		item4.put("imageItem", R.drawable.fashionapp_types4);
		item4.put("textItem", "");
		items.add(item4);
		
		//types5-园区邮箱
		Map<String, Object> item5 = new HashMap<String, Object>();
		item5.put("imageItem", R.drawable.fashionapp_types5);
		item5.put("textItem", "");
		items.add(item5);
								
		//types6-会议预定
		Map<String, Object> item6 = new HashMap<String, Object>();
		item6.put("imageItem", R.drawable.fashionapp_types6);
		item6.put("textItem", "");
		items.add(item6);
		
		// 实例化一个适配器
		SimpleAdapter adapter = new SimpleAdapter(this, items,
				R.layout.grid_item, new String[] { "imageItem", "textItem" },
				new int[] { R.id.image_item, R.id.text_item });
		
		// 获得GridView实例
		gridview = (GridView) findViewById(R.id.mygridview);
		
		// 将GridView和数据适配器关联
		gridview.setAdapter(adapter);
		
		// 点击跳转事件
		gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				switch (arg2) {
				case 0:
					forward(UiGuestMySiteWeibo.class);//微博平台
					break;
				case 1:
					forward(UiGuestMySiteWeixin.class);//微信平台
					break;
				case 2:
					forward(UiGuestFashionBbs.class);//园区论坛
					break;
				case 3:
					forward(UiGuestFashionMap.class);//园区地图
					break;
				case 4:
					forward(UiGuestFashionMail.class);//园区邮箱
					break;
				case 5:
					forward(UiGuestFashionMeet.class);//会议预定
					break;
				}
			}
		});
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiGuestZixunList.class);
		}
		return super.onKeyDown(keyCode, event);
	}
}
package com.can2do.incubation.guest.ui;

import android.content.Intent;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.can2do.incubation.base.BaseUiWeb;
import com.can2do.incubation.guest.base.GuestC;
import com.can2do.incubation.ui.UiIndex;
import com.can2do.ishare.R;
//import com.zjgx.app.ui.SysApplication;
//图片新闻
public class UiZixunProductList extends BaseUiWeb {
	
	private WebView mWebViewMap;
	private long index_exitTime;
	
	@Override
	public void onStart() {
		super.onStart();
		
		setContentView(R.layout.map);
		//SysApplication.getInstance().addActivity(this);
		mWebViewMap = (WebView) findViewById(R.id.web_map);
		mWebViewMap.getSettings().setJavaScriptEnabled(true);
		mWebViewMap.setWebViewClient(new WebViewClient(){

		});
		mWebViewMap.loadUrl(GuestC.web.products);
		
		this.setWebView(mWebViewMap);
		this.startWebView();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebViewMap.canGoBack()) {
			mWebViewMap.goBack();
			return true;
			}else if (keyCode == KeyEvent.KEYCODE_BACK) {
				getOut();
				return true;
				} else {
					return super.onKeyDown(keyCode, event);
					}
		}
	
	protected void getOut() {
		long nowTime = System.currentTimeMillis();
		if (nowTime - index_exitTime > 3000) {
			Toast toast = Toast.makeText(this, "再按一次关闭图片新闻窗口！", Toast.LENGTH_SHORT);
			toast.show();
			index_exitTime = nowTime;
		} else {
			Intent intent = new Intent(UiZixunProductList.this,UiIndex.class);
			startActivity(intent);
			this.finish();
		}
	}
}
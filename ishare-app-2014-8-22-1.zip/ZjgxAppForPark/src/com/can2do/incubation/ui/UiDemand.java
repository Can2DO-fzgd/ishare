package com.can2do.incubation.ui;

import java.util.HashMap;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.can2do.incubation.base.BaseHandler;
import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.incubation.model.Customer1;
import com.can2do.incubation.model.Zixun;
import com.can2do.incubation.util.AppCache;
import com.can2do.incubation.util.AppFilter;
import com.can2do.incubation.util.UIUtil;
import com.can2do.ishare.R;

@SuppressLint("CutPasteId")
public class UiDemand extends BaseUiAuth {

	private String newsId = null;
	private String newspathurl;
	private String name = null;
	private String ctype = null;
	private String content = null;
	private String customerId = null;
	private Button addfansBtn = null;
	private ImageView faceImage = null;
	private String faceImageUrl = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_zixun1);
		//SysApplication.getInstance().addActivity(this);

		// set handler
		this.setHandler(new NewsHandler(this));

		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);
		
		// get params
		Bundle params = this.getIntent().getExtras();
		newsId = params.getString("newsId");
		name = params.getString("name");
		ctype = params.getString("ctype");
		content = params.getString("content");
		
		newspathurl = "有人分享了高新移动园区的资讯给你！ " 
				+ "\n【资讯标题为】：" + name 
				+ "   资讯详情请下载移动园区应用查看。"
				+ "\nhttp://www.can2do.com/platform/zjgx/front/mobile/index.html";

		// do add fans
		addfansBtn = (Button) this.findViewById(R.id.app_news_btn_addfans);
		addfansBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// prepare news data
				HashMap<String, String> urlParams = new HashMap<String, String>();
				urlParams.put("customerId", customerId);
				urlParams.put("message", "有人关注你了！");
				doTaskAsync(C.task.fansAdd, C.api.fansAdd, urlParams);
			}
		});

		OnClickListener mOnClickListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.app_news_btn_share:
					Share();
					break;
//				case R.id.app_news_btn_collect:
//					Collect();
//					break;

				}
			}

		};
		findViewById(R.id.app_news_btn_share).setOnClickListener(
				mOnClickListener);
//		findViewById(R.id.app_news_btn_collect).setOnClickListener(
//				mOnClickListener);

		// prepare news data
		HashMap<String, String> newsParams = new HashMap<String, String>();
		newsParams.put("newsId", newsId);
		this.doTaskAsync(C.task.demandView, C.api.demandView, newsParams);
	}

	// 分享
	protected void Share() {
		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.setType("image/*");
		intent.putExtra(Intent.EXTRA_SUBJECT, "高新移动园区资讯分享！");
		intent.putExtra(Intent.EXTRA_TEXT,newspathurl);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(Intent.createChooser(intent, getTitle()));
	}

//	// 收藏
//	protected void Collect() {
//		HashMap<String, String> commentParams1 = new HashMap<String, String>();
//		commentParams1.put("newsId", newsId);
//		commentParams1.put("title", name);
//		commentParams1.put("content", content);
//		this.doTaskAsync(C.task.news3Collect, C.api.zixunCollect,commentParams1);
//	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods

	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
		case C.task.demandView:
			try {
				Zixun news = (Zixun) message.getResult("Zixun");
				TextView textUptime = (TextView) this
						.findViewById(R.id.app_news_text_uptime);
				TextView textTitle = (TextView) this
						.findViewById(R.id.app_news_text_title);
				TextView textContent = (TextView) this
						.findViewById(R.id.app_news_text_content);
				textUptime.setText(news.getUptime());
				textTitle.setText(AppFilter.getHtml(news.getName()));
				textContent.setText(AppFilter.getHtml(news.getContent()));
				Customer1 customer = (Customer1) message.getResult("Customer1");
				TextView textCustomerName = (TextView) this
						.findViewById(R.id.app_news_text_customer_name);
				TextView testCustomerInfo = (TextView) this
						.findViewById(R.id.app_news_text_customer_info);
				textCustomerName.setText(customer.getSign());
				testCustomerInfo
						.setText(UIUtil.getCustomerInfo(this, customer));
				// set customer id
				customerId = customer.getId();
				// load face image async
				faceImage = (ImageView) this
						.findViewById(R.id.app_news_image_face);
				faceImageUrl = customer.getFaceurl();
				loadImage(faceImageUrl);
			} catch (Exception e) {
				e.printStackTrace();
				toast(e.getMessage());
			}
			break;
			
		case C.task.fansAdd:
			if (message.getCode().equals("10000")) {
				toast("关注成功！");
				// refresh customer data
				HashMap<String, String> cvParams = new HashMap<String, String>();
				cvParams.put("customerId", customerId);
				this.doTaskAsync(C.task.customerView, C.api.customerView,cvParams);
			} else {
				toast("关注失败！可能你已经关注了他");
			}
			break;
			
		case C.task.customerView:
			try {
				// update customer info
				final Customer1 customer = (Customer1) message
						.getResult("Customer1");
				TextView textInfo = (TextView) this
						.findViewById(R.id.app_news_text_customer_info);
				textInfo.setText(UIUtil.getCustomerInfo(this, customer));
			} catch (Exception e) {
				e.printStackTrace();
				toast(e.getMessage());
			}
			break;
			
//		case C.task.news3Collect:
//			try {
//				Zixun news = (Zixun) message.getResult("Zixun");
//				TextView textUptime = (TextView) this
//						.findViewById(R.id.app_news_text_uptime);
//				TextView textContent = (TextView) this
//						.findViewById(R.id.app_news_text_content);
//				textUptime.setText(news.getUptime());
//				textContent.setText(news.getContent());
//				Customer1 customer = (Customer1) message.getResult("Customer1");
//				TextView textCustomerName = (TextView) this
//						.findViewById(R.id.app_news_text_customer_name);
//				TextView testCustomerInfo = (TextView) this
//						.findViewById(R.id.app_news_text_customer_info);
//				textCustomerName.setText(customer.getUsername());
//				testCustomerInfo
//						.setText(UIUtil.getCustomerInfo(this, customer));
//				// set customer id
//				customerId = customer.getId();
//				// load face image async
//				faceImage = (ImageView) this
//						.findViewById(R.id.app_news_image_face);
//				faceImageUrl = customer.getFaceurl();
//				loadImage(faceImageUrl);
//			} catch (Exception e) {
//				e.printStackTrace();
//				toast(e.getMessage());
//			}
//			break;
		}
	}

	@Override
	public void onNetworkError(int taskId) {
		super.onNetworkError(taskId);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// other methods

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			this.forward(UiTypesTwelve.class);
		}
		return super.onKeyDown(keyCode, event);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes

	@SuppressLint("HandlerLeak")
	private class NewsHandler extends BaseHandler {
		public NewsHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					Bitmap face = AppCache.getImage(faceImageUrl);
					faceImage.setImageBitmap(face);
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}
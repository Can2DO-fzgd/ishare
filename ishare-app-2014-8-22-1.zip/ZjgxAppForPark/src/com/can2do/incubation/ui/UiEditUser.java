package com.can2do.incubation.ui;

import java.util.HashMap;

import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.ishare.R;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

public class UiEditUser extends BaseUiAuth {
	
	private EditText mEditName;
	private EditText mEditPassword;
	private Button mEditSubmit;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_edit_user);
		//SysApplication.getInstance().addActivity(this);
		// show keyboard
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
		
		// init ui
		mEditName = (EditText) this.findViewById(R.id.app_edit_name);
		mEditPassword = (EditText) this.findViewById(R.id.app_edit_pass);
		mEditSubmit = (Button) this.findViewById(R.id.app_edit_submit);
		
		// bind action logic
		Bundle params = this.getIntent().getExtras();
		final int action = params.getInt("action");
		
		switch (action) {
			case C.action.edittext.CONFIGNAME:
				mEditName.setText(params.getString("name"));
				mEditPassword.setText(params.getString("password"));
				mEditSubmit.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						String input = mEditName.getText().toString();
						String input1 = mEditPassword.getText().toString();
						customer.setUsername(input); // update local member
						customer.setPassword(input1);// update local member 
						HashMap<String, String> urlParams = new HashMap<String, String>();
						urlParams.put("key", "username");
						urlParams.put("val", input);
						urlParams.put("password", input1);
						doTaskAsync(C.task.customerEdit, C.api.customerEdit, urlParams);
					}
				});
				break;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);
		doFinish();
	}
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			doFinish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
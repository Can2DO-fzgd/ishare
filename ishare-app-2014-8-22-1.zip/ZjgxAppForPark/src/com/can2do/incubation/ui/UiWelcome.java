package com.can2do.incubation.ui;

import android.os.Bundle;
import android.os.Handler;

import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.guest.ui.UiGuestZixunList;
import com.can2do.ishare.tab.Ui_Main;
import com.can2do.ishare.R;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class UiWelcome extends BaseUi {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_welcome);
		
		// login submit
//		OnClickListener mOnClickListener = new OnClickListener() {
//		@Override
//		public void onClick(View v) {
//			switch (v.getId()) {
//			case R.id.splashtitle:
//				forward(Ui_Main.class);
//				break;
//				}
//			}
//		};
//		findViewById(R.id.splashtitle).setOnClickListener(mOnClickListener);
//		
//		
//		PackageManager pm = getPackageManager();
//		try {
//		    PackageInfo pi = pm.getPackageInfo("com.can2do.ishare", 0);
//		    TextView versionNumber = (TextView) findViewById(R.id.versionNumber);
//		    versionNumber.setText("Version " + pi.versionName);
//		} catch (NameNotFoundException e) {
//		    e.printStackTrace();
//		}
		
		PackageManager pm = getPackageManager();
		try {
		    PackageInfo pi = pm.getPackageInfo("com.can2do.ishare", 0);
		    TextView versionNumber = (TextView) findViewById(R.id.versionNumber);
		    versionNumber.setText("Version " + pi.versionName);
		} catch (NameNotFoundException e) {
		    e.printStackTrace();
		}

		new Handler().postDelayed(new Runnable(){

		@Override
		public void run() {
			Intent intent = new Intent(UiWelcome.this,Ui_Main.class);
		    startActivity(intent);
		    UiWelcome.this.finish();
		}
		}, 1500);
	}
}
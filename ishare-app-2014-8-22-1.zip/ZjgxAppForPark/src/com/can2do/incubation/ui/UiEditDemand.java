package com.can2do.incubation.ui;

import java.util.HashMap;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.ishare.R;

public class UiEditDemand extends BaseUiAuth {

	String mes = "Wolf";
	String arg = "";
	
	//private static final String[] m_arr = { "特区公告", "特区新闻", "政策", "发文","特区成果","媒体报道","政策解读","材料阅读","优惠政策","人才政策"};
	private static final String[] m_arr = { "园区需求" };
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_writedemand);

		// get params
		// show keyboard
		((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
				.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
		final Spinner s1 = (Spinner) findViewById(R.id.Spinner01);
		s1.setPrompt("请选择发布信息模块");
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, m_arr);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		s1.setAdapter(adapter);

		// bind action logic
		findViewById(R.id.app_write_submit).setOnClickListener(
		new OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText mWritetitle = (EditText) findViewById(R.id.app_write_title);
				EditText mWriteText = (EditText) findViewById(R.id.app_write_text);
				EditText mWriteMessage = (EditText) findViewById(R.id.news_notice_content);
				HashMap<String, String> urlParams = new HashMap<String, String>();
				urlParams.put("name", mWritetitle.getText().toString());
				urlParams.put("content", mWriteText.getText().toString());
				urlParams.put("ctype", ngetSelectedItem(s1.getSelectedItem().toString()));
					this.doTaskAsync(C.task.demandCreate,C.api.demandCreate, urlParams);
				for (int i = 0; i < 200; i++)
				{
					String  customerid = Integer.toString(i);;
					urlParams.put("customerId", customerid);
					urlParams.put("message", mWriteMessage.getText().toString());
						doTaskAsync(C.task.newsnoticeAdd, C.api.newsnoticeAdd, urlParams);
				}
			}

			public void doTaskAsync(int taskId, String taskUrl,
					HashMap<String, String> taskArgs) {
				showLoadBar();
				taskPool.addTask(taskId, taskUrl, taskArgs,new BaseTask() {
					@Override
					public void onComplete(String httpResult) {
						sendMessage(BaseTask.TASK_COMPLETE,this.getId(), httpResult);
			}

			@Override
			public void onError(String error) {
			sendMessage(BaseTask.NETWORK_ERROR,this.getId(), null);
			}
			}, 0);
			}
		});
		}

	public void dispToast(String str) {
		Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
	}

	// async task callback methods

	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);
		doFinish();
	}

	@Override
	public void onNetworkError(int taskId) {
		super.onNetworkError(taskId);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// other methods

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			doFinish();
		}
		return super.onKeyDown(keyCode, event);
	}
	
	// //////////////////////////////////////////////////////////////////////////////////////////////
	public String ngetSelectedItem(String item){
		if(item.equals("园区需求")){
			return "2";
		}
//		if(item.equals("特区新闻")){
//			return "2";
//		}
//		if(item.equals("政策")){
//			return "12";
//		}
//		if(item.equals("发文")){
//			return "13";
//		}
//		if(item.equals("特区成果")){
//			return "5";
//		}
//		if(item.equals("媒体报道")){
//			return "8";
//		}
//		if(item.equals("政策解读")){
//			return "7";
//		}
//		if(item.equals("材料阅读")){
//			return "6";
//		}
//		if(item.equals("优惠政策")){
//			return "14";
//		}
//		if(item.equals("人才政策")){
//			return "15";
//		}
		return "0";
	} 
}
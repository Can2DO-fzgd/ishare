package com.can2do.incubation.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.can2do.incubation.base.BaseHandler;
import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.incubation.list.ExpandList;
import com.can2do.incubation.model.Collect;
import com.can2do.incubation.model.Customer1;
import com.can2do.incubation.util.AppCache;
import com.can2do.incubation.util.AppUtil;
import com.can2do.incubation.util.UIUtil;
import com.can2do.ishare.R;

public class UiCollect extends BaseUiAuth {
	
	private ImageView faceImage;
	private String faceImageUrl;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_list_collect);
		
		// set handler
		this.setHandler(new NewsallHandler(this));
		
		// tab button
		//ImageButton ib = (ImageButton) this.findViewById(R.id.main_tab_2);
		//ib.setImageResource(R.drawable.tab_heart_2);	
	}
	
	@Override
	public void onStart () {
		super.onStart();
		
		// prepare customer data
		HashMap<String, String> cvParams = new HashMap<String, String>();
		cvParams.put("customerId", customer.getId());
		this.doTaskAsync(C.task.customerView, C.api.customerView, cvParams);
		
		HashMap<String, String> newsParams = new HashMap<String, String>();
		newsParams.put("customerId", customer.getId());
		newsParams.put("pageId", "1");
		newsParams.put("pageCount", "10");
		this.doTaskAsync(C.task.news3CollectList, C.api.zixunCollectList, newsParams);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	@SuppressWarnings("unchecked")
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);
		
		switch (taskId) {
			case C.task.customerView:
				try {
					final Customer1 customer = (Customer1) message.getResult("Customer1");
					TextView textName = (TextView) this.findViewById(R.id.app_news_text_customer_name);
					TextView textInfo = (TextView) this.findViewById(R.id.app_news_text_customer_info);
					textName.setText(customer.getSign());
					textInfo.setText(UIUtil.getCustomerInfo(this, customer));
					// load face image async
					faceImage = (ImageView) this.findViewById(R.id.app_news_image_face);
					faceImageUrl = customer.getFaceurl();
					loadImage(faceImageUrl);
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
				
			case C.task.news3CollectList:
				try {
					final ArrayList<Collect> newsList = (ArrayList<Collect>) message.getResultList("Collect");
					String[] from = {
						Collect.COL_CONTENT,
						Collect.COL_UPTIME,
						Collect.COL_NEWSID
					};
					int[] to = {
						R.id.tpl_list_news_text_content,
						R.id.tpl_list_news_text_uptime,
						R.id.tpl_list_news_text_comment
					};
					// use expandlist to do this
					ExpandList el = new ExpandList(this, AppUtil.dataToList(newsList, from), R.layout.tpl_list_news_all, from, to);
					LinearLayout layout = (LinearLayout) this.findViewById(R.id.app_news_list_view);
					layout.removeAllViews(); // clean first
					el.setDivider(R.color.divider3);
					el.setOnItemClickListener(new ExpandList.OnItemClickListener() {
						@Override
						public void onItemClick(View view, int pos) {
							Bundle params = new Bundle();
							params.putString("newsId", newsList.get(pos).getNewsid());
							overlay(UiNews1.class, params);
						}
					});
					el.render(layout);
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
		}
	}
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			this.forward(UiNewsall.class);
		}
		return super.onKeyDown(keyCode, event);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes
	
	@SuppressLint("HandlerLeak")
	private class NewsallHandler extends BaseHandler {
		public NewsallHandler(BaseUi ui) {
			super(ui);
		}
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
					case BaseTask.LOAD_IMAGE:
						Bitmap face = AppCache.getImage(faceImageUrl);
						faceImage.setImageBitmap(face);
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}
package com.can2do.incubation.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;

import com.can2do.incubation.base.BaseHandler;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.guest.ui.UiGuestZixunList;
import com.can2do.incubation.guest.ui.UiMySiteCompanyMyPage;
import com.can2do.incubation.list.NewsList;
import com.can2do.ishare.R;

public class UiMySite extends BaseUiAuth {

	private NewsList newsListAdapter;
	private GridView gridview;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_my_site);
		
		// set handler
		this.setHandler(new IndexHandler(this));

		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_2);
		ib.setImageResource(R.drawable.top_mysite_2);

		List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
		
		//types1-微站管理
		Map<String, Object> item1 = new HashMap<String, Object>();
		item1.put("imageItem", R.drawable.mysite_types1);
		item1.put("textItem", "");
		items.add(item1);
				
		//types2-我的资讯
		Map<String, Object> item2 = new HashMap<String, Object>();
		item2.put("imageItem", R.drawable.mysite_types2);
		item2.put("textItem", "");
		items.add(item2);
		
		//types3-帐号设置
		Map<String, Object> item3 = new HashMap<String, Object>();
		item3.put("imageItem", R.drawable.mysite_types3);
		item3.put("textItem", "");
		items.add(item3);
		
		// 实例化一个适配器
		SimpleAdapter adapter = new SimpleAdapter(this, items,
				R.layout.grid_item, new String[] { "imageItem", "textItem" },
				new int[] { R.id.image_item, R.id.text_item });
		
		// 获得GridView实例
		gridview = (GridView) findViewById(R.id.mygridview);
		
		// 将GridView和数据适配器关联
		gridview.setAdapter(adapter);
		
		// 点击跳转事件
		gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				switch (arg2) {
				case 0:
					forward(UiMySiteCompanyMyPage.class);//微站管理
					break;
				case 1:
					forward(UiNewsall.class);//我的资讯
					break;
				case 2:
					forward(UiConfig.class);//帐号设置
					break;
				}
			}
		});
	}

	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					newsListAdapter.notifyDataSetChanged();
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiIndex.class);
		}
		return super.onKeyDown(keyCode, event);
	}
}
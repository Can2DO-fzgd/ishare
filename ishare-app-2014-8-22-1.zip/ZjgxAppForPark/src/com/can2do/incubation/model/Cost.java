package com.can2do.incubation.model;

import com.can2do.incubation.base.BaseModel;

public class Cost extends BaseModel {
	
	// model columns
	public final static String COL_ID = "id";
	public final static String COL_FACE = "face";
	public final static String COL_DESC = "desc";
	public final static String COL_SIGN = "sign";
	public final static String COL_MEMID = "memid";
	public final static String COL_AUTHOR = "author";
	public final static String COL_FEETYPE = "feetype";
	public final static String COL_FDATE = "fdate";
	public final static String COL_FEE	= "fee";
	public final static String COL_JF	= "jf";
	public final static String COL_UPTIME = "uptime";
	
	private String id;
	private String face;
	private String desc;
	private String sign;
	private String memid;
	private String author;
	private String feetype;
	private String fdate;
	private String fee;
	private String jf;
	private String uptime;
	
	public Cost () {}
	
	public String getId () {
		return this.id;
	}
	
	public void setId (String id) {
		this.id = id;
	}
	
	public String getFace () {
		return this.face;
	}
	
	public void setFace (String face) {
		this.face = face;
	}
	
	public String getDesc () {
		return this.desc;
	}
	
	public void setDesc (String desc) {
		this.desc = desc;
	}
	
	public String getSign () {
		return this.sign;
	}
	
	public void setSing (String sign) {
		this.sign = sign;
	}
	
	public String getMemid () {
		return this.memid;
	}
	
	public void setMemid (String memid) {
		this.memid = memid;
	}
	
	public String getAuthor () {
		return this.author;
	}
	
	public void setAuthor (String author) {
		this.author = author;
	}
	
	public String getFeetype () {
		return this.feetype;
	}
	
	public void setFeetype (String feetype) {
		this.feetype = feetype;
	}
	
	public String getFdate () {
		return this.fdate;
	}
	
	public void setFdate (String fdate) {
		this.fdate = fdate;
	}
	
	public String getFee () {
		return this.fee;
	}
	
	public void setFee (String fee) {
		this.fee = fee;
	}
	
	public String getJf () {
		return this.jf;
	}
	
	public void setJf (String jf) {
		this.jf = jf;
	}
	
	public String getUptime () {
		return this.uptime;
	}
	
	public void setUptime (String uptime) {
		this.uptime = uptime;
	}
}
package com.can2do.incubation.model;

import com.can2do.incubation.base.BaseModel;

public class Notice extends BaseModel {
	
	// model columns
	public final static String COL_ID = "id";
	public final static String COL_CUSTOMERID = "customerid";
	public final static String COL_FRIENDSCOUNT = "friendscount";
	public final static String COL_NEWSNOTICECOUNT = "newsnoticecount";
	public final static String COL_MESSAGE = "message";
	
	private String id;
	private String customerid;
	private String friendscount;
	private String newsnoticecount;
	private String message;
	
	public Notice () {}
	
	public String getId () {
		return this.id;
	}
	
	public void setId (String id) {
		this.id = id;
	}
	
	public String getCustomerid () {
		return this.customerid;
	}
	
	public void setCustomerid (String customerid) {
		this.customerid = customerid;
	}
	
	public String getNewsnoticecount() {
		return this.newsnoticecount;
	}
	
	public void setNewsnoticecount(String newsnoticecount) {
		this.newsnoticecount =  newsnoticecount;
	}
	
	public String getFriendscount() {
		return this.friendscount;
	}
	
	public void setFriendscount(String friendscount) {
		this.friendscount =  friendscount;
	}
	
	public String getMessage () {
		return this.message;
	}
	
	public void setMessage (String message) {
		this.message = message;
	}
}
package com.can2do.incubation.model;

import com.can2do.incubation.base.BaseModel;

public class Customer1 extends BaseModel {
	
	// model columns
	public final static String COL_ID = "id";
	public final static String COL_SID = "sid";
	public final static String COL_USERNAME = "username";
	public final static String COL_PASSWORD = "password";
	public final static String COL_SIGN = "sign";
	public final static String COL_FACE = "face";
	public final static String COL_FACEURL = "faceurl";
	public final static String COL_NEWSCOUNT = "newscount";
	public final static String COL_FANSCOUNT = "friendscount";
	public final static String COL_PHONE = "PHONE";
	public final static String COL_UPTIME = "uptime";
	
	private String id;
	private String sid;
	private String username;
	private String password;
	private String sign;
	private String face;
	private String faceurl;
	private String newscount;
	private String friendscount;
	private String phone;
	private String uptime;
	
	// default is no login
	private boolean isLogin = false;
	private boolean isRegister = false;
	
	// single instance for login
	static private Customer1 customer = null;
	
	static public Customer1 getInstance () {
		if (Customer1.customer == null) {
			Customer1.customer = new Customer1();
		}
		return Customer1.customer;
	}
	
	public Customer1 () {}
	
	public String getId () {
		return this.id;
	}
	
	public void setId (String id) {
		this.id = id;
	}
	
	public String getSid () {
		return this.sid;
	}
	
	public void setSid (String sid) {
		this.sid = sid;
	}
	
	public String getUsername () {
		return this.username;
	}
	
	public void setUsername (String username) {
		this.username = username;
	}
	
	public String getPassword () {
		return this.password;
	}
	
	public void setPassword (String password) {
		this.password = password;
	}
	
	public String getSign () {
		return this.sign;
	}
	
	public void setSign (String sign) {
		this.sign = sign;
	}
	
	public String getFace () {
		return this.face;
	}
	
	public void setFace (String face) {
		this.face = face;
	}
	
	public String getFaceurl () {
		return this.faceurl;
	}
	
	public void setFaceurl (String faceurl) {
		this.faceurl = faceurl;
	}
	
	public String getUptime () {
		return this.uptime;
	}
	
	public void setUptime (String uptime) {
		this.uptime = uptime;
	}
	
	public String getNewscount () {
		return this.newscount;
	}
	
	public void setNewscount (String newscount) {
		this.newscount = newscount;
	}
	
	public String getFanscount () {
		return this.friendscount;
	}
	
	public void setFanscount (String friendscount) {
		this.friendscount = friendscount;
	}
	
	public Boolean getLogin () {
		return this.isLogin;
	}
	
	public void setLogin (boolean isLogin) {
		this.isLogin = isLogin;
	}
	
	public String getPhone () {
		return this.phone;
	}
	
	public void setPhone (String phone) {
		this.phone = phone;
	}
	
	public Boolean getRegister () {
		return this.isRegister;
	}
	
	public void setRegister (boolean isRegister) {
		this.isRegister = isRegister;
	}
}
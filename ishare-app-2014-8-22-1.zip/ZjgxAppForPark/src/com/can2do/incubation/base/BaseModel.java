package com.can2do.incubation.base;

public class BaseModel {
	
}
package com.can2do.incubation.base;

import com.can2do.incubation.model.Customer1;

public class BaseAuth {
	
	static public boolean isLogin () {
		Customer1 customer = Customer1.getInstance();
		if (customer.getLogin() == true) {
			return true;
		}
		return false;
	}
	
	static public void setLogin (Boolean status) {
		Customer1 customer = Customer1.getInstance();
		customer.setLogin(status);
	}
	
	static public void setRegister(Boolean status){
		Customer1 customer = Customer1.getInstance();
		customer.setRegister(status);
	}
	
	static public void setCustomer (Customer1 mc) {
		Customer1 customer = Customer1.getInstance();
		customer.setId(mc.getId());
		customer.setSid(mc.getSid());
		customer.setUsername(mc.getUsername());
		customer.setSign(mc.getSign());
		customer.setFace(mc.getFace());
	}
	
	static public Customer1 getCustomer () {
		return Customer1.getInstance();
	}
}
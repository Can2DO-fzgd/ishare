package com.can2do.incubation.base;

import android.annotation.SuppressLint;

public final class C {
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// core settings (important)
	
	public static final class dir {
		@SuppressLint("SdCardPath")
		public static final String base				= "/sdcard/MeBUS";
		public static final String faces			= base + "/faces";
		public static final String images			= base + "/images";
	}
	
	public static final class api {
		public static final String base					= "http://www.can2do.com:8001";
		//public static final String base				    = "http://api.njibi.com.cn";//接口基本地址
		public static final String index1			    = "/index1/index1";//首页测试
		public static final String login			    = "/index1/login1";//登录
		public static final String register			    = "/index1/register1";//注册
		public static final String logout		     	= "/index1/logout1";//登出
		public static final String faceView 			= "/image/faceView";//查看用户头像
		public static final String faceList 			= "/image/faceList";//用户头像列表
		public static final String zixunList			= "/zjgxzixun1/zixunList1";//简单资讯列表
		public static final String zixunView			= "/zjgxzixun1/zixunView1";//资讯正文
		public static final String zixunCreate			= "/zjgxzixun1/zixunCreate1";//发布资讯
		public static final String zixunCollectList		= "/zjgxzixuncollect1/collectList1";//收藏列表
		public static final String zixunCollect			= "/zjgxzixuncollect1/collectCreate1";//资讯收藏
		public static final String zixunTypesList		= "/zjgxzixun1/zixunTypesList1";//多功能资讯列表
		public static final String zixunTypes			= "/zjgxzixun1/zixunTypes1";//资讯重新分类接口
		public static final String commentList			= "/zjgxzixuncomment1/commentList1";//资讯评论列表
		public static final String commentCreate		= "/zjgxzixuncomment1/commentCreate1";//发布评论
		public static final String customerView			= "/customer1/customerView1";//查看用户信息
		public static final String customerEdit			= "/customer1/customerEdit1";//修改用户信息
		public static final String fansAdd				= "/customer1/fansAdd1";//添加关注
		public static final String newsnoticeAdd		= "/notify/newsnoticeAdd";//增加通知接口
		public static final String fansDel				= "/customer1/fansDel1";//删除关注
		public static final String notice				= "/notify/notice";//获取通知接口
		public static final String demandTypesList   	= "/zjgxdemand1/demandTypesList1";//园区需求列表
		public static final String demandView			= "/zjgxdemand1/demandView1";//查看园区需求
		public static final String enterpriseList		= "/zjgxcost/enterpriseList";//企业用户列表
		public static final String costTypesList		= "/zjgxcost/costTypesList";//费用列表
		public static final String costView				= "/zjgxcost/costView";//费用详情
		public static final String customer1View		= "/customer/customerView";//查看企业用户
		public static final String fansAdd1				= "/customer/fansAdd";//关注企业用户
		public static final String demandTypesList1   	= "/zjgxdemand/demandTypesList";//企业需求列表
		public static final String demandView1			= "/zjgxdemand/demandView";//企业需求详情
		public static final String demandCreate			= "/zjgxdemand1/demandCreate1";//园区需求发布
	}
	
	public static final class task {
		public static final int index				= 1001;
		public static final int login				= 1002;
		public static final int register            = 1000;
		public static final int logout				= 1003;
		public static final int faceView			= 1004;
		public static final int faceList			= 1005;
		public static final int news3List			= 1006;
		public static final int news3View			= 1007;
		public static final int news3Create			= 1008;
		public static final int commentList		    = 1009;
		public static final int commentCreate		= 1010;
		public static final int customerView		= 1011;
		public static final int customerEdit		= 1012;
		public static final int fansAdd				= 1013;
		public static final int fansDel				= 1014;
		public static final int notice				= 1015;
		public static final int news3Collect		= 1016;
		public static final int news3CollectList    = 1017; 
		public static final int news3TypesList      = 1018;  
		public static final int news3Types          = 1019;
		public static final int newsnoticeAdd		= 1020;
		public static final int demandTypesList		= 1021;
		public static final int demandView			= 1022;
		public static final int enterpriseList		= 1023;
		public static final int costTypesList		= 1024;
		public static final int costView			= 1025;
		public static final int customer1View		= 1026;
		public static final int fansAdd1		    = 1027;
		public static final int demandTypesList1	= 1028;
		public static final int demandView1			= 1029;
		public static final int demandCreate		= 1030;
	}
	
	public static final class err {
		public static final String network			= "网络出错了！请检查你的网络";
		public static final String message			= "消息错误";
		public static final String jsonFormat		= "消息格式错误";
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// intent & action settings
	
	public static final class intent {
		public static final class action {
			public static final String EDITTEXT		= "com.can2do.incubation.EDITTEXT";
			public static final String EDITNEWS		= "com.can2do.incubation.EDITNEWS";
			public static final String EDITUSER		= "com.can2do.incubation.EDITUSER";
			public static final String EDITDEMAND	= "com.can2do.incubation.EDITDEMAND";
		}
	}
	
	public static final class action {
		public static final class edittext {
			public static final int CONFIGSIGN		= 2001;
			public static final int CONFIGNAME      = 2002;
			public static final int CONFIGPASS      = 2003;
			public static final int COMMENT			= 2004;
			public static final int COLLECT         = 2005;
		}
	}
		////////////////////////////////////////////////////////////////////////////////////////////////
		// additional settings

		public static final class web {
			public static final String base				= "http://map.njibi.com.cn";//地址应用域名
			public static final String gomap			=  base + "/gomap.php";//地图
	}
}
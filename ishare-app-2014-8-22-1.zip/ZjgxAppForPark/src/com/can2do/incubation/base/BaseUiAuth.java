package com.can2do.incubation.base;

import com.can2do.incubation.base.BaseAuth;
import com.can2do.incubation.cost.ui.UiCustomerList;
import com.can2do.incubation.guest.base.BaseGuestUiMenu;
import com.can2do.incubation.guest.ui.UiFashionMap;
import com.can2do.incubation.guest.ui.UiFashionMeet;
import com.can2do.incubation.guest.ui.UiGuestZixunList;
import com.can2do.incubation.guest.ui.UiMoveOaManagement;
import com.can2do.incubation.guest.ui.UiMySiteCompanyList;
import com.can2do.incubation.guest.ui.UiMySiteCompanyMyPage;
import com.can2do.incubation.guest.ui.UiMySiteServerList;
import com.can2do.incubation.model.Customer1;
import com.can2do.incubation.ui.UiContentUs;
import com.can2do.incubation.ui.UiFashionApp;
import com.can2do.incubation.ui.UiIndex;
import com.can2do.incubation.ui.UiLogin;
import com.can2do.incubation.ui.UiMoveOa;
import com.can2do.incubation.ui.UiMySite;
import com.can2do.incubation.ui.UiTypesEleven;
import com.can2do.incubation.ui.UiTypesTwelve;
import com.can2do.ishare.R;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

public class BaseUiAuth extends BaseUi {
	
	private RelativeLayout level2;
	private RelativeLayout level3;
	
	private boolean isLevel2Show = true;
	private boolean isLevel3Show = true;
	
	private final int MENU_APP_WRITE = 0;
	private final int MENU_APP_LOGOUT = 1;
	private final int MENU_APP_ABOUT = 2;
	private final int MENU_DEMO_MAP = 3;
	private final int MENU_DEMO_DEMAND = 4;
	
	protected static Customer1 customer = null;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if (!BaseAuth.isLogin()) {
			this.forward(UiLogin.class);
			this.onStop();
		} else {
			customer = BaseAuth.getCustomer();
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		
		this.bindMainTop();
		this.bindMainTab();
		this.bindMainMenu();
		this.bindMainLeft();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, MENU_APP_WRITE, 0, R.string.menu_demo_demand).setIcon(android.R.drawable.ic_menu_add);
		menu.add(0, MENU_APP_LOGOUT, 0, R.string.menu_app_logout).setIcon(android.R.drawable.ic_menu_close_clear_cancel);
		menu.add(0, MENU_APP_ABOUT, 0, R.string.menu_app_about).setIcon(android.R.drawable.ic_menu_info_details);
		menu.add(0, MENU_DEMO_MAP, 0, R.string.menu_demo_map).setIcon(android.R.drawable.ic_menu_view);
//		menu.add(0, MENU_DEMO_DEMAND, 0, R.string.menu_demo_demand).setIcon(android.R.drawable.ic_menu_add);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case MENU_APP_WRITE: {
				doEditDemand();
				break;
			}
			case MENU_APP_LOGOUT: {
				doLogout(); 
				toast(this.getString(R.string.msg_logoutsucces));
				forward(UiGuestZixunList.class);
				break;
			}
			case MENU_APP_ABOUT:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setTitle(R.string.menu_app_about);
				String appName = this.getString(R.string.app_name);
				String appVersion = this.getString(R.string.app_version);
				String appAbout = this.getString(R.string.app_about);
				builder.setMessage(appName + " " + appVersion + appAbout);
				builder.setIcon(R.drawable.about);
				builder.setPositiveButton(R.string.btn_cancel, null);
				builder.show();
				break;
			case MENU_DEMO_MAP:
				forward(UiFashionMap.class);
				break;
//			case MENU_DEMO_DEMAND:
//				doEditDemand();
//				break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private void bindMainTop () {
		ImageButton bTopzixun = (ImageButton) findViewById(R.id.main_top_1);
		ImageButton bTopfashion = (ImageButton) findViewById(R.id.main_top_2);
		ImageButton bTopcontent = (ImageButton) findViewById(R.id.main_top_3);
		ImageButton bTopmoveoa = (ImageButton) findViewById(R.id.main_top_4);
		ImageButton bTopmysite = (ImageButton) findViewById(R.id.main_top_5);
		if (bTopzixun != null && bTopfashion != null && bTopcontent != null && bTopmoveoa != null) {
		OnClickListener mOnClickListener = new OnClickListener() {
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.main_top_1:
							forward(UiMoveOa.class);
							break;
						case R.id.main_top_2:
							forward(UiMySite.class);
							break;
						case R.id.main_top_3:
							forward(UiIndex.class);
							break;
						case R.id.main_top_4:
							forward(UiFashionApp.class);
							break;
						case R.id.main_top_5:
							forward(UiContentUs.class);
							break;
					}
				}
			};
			bTopzixun.setOnClickListener(mOnClickListener);
			bTopfashion.setOnClickListener(mOnClickListener);
			bTopcontent.setOnClickListener(mOnClickListener);
			bTopmoveoa.setOnClickListener(mOnClickListener);
			bTopmysite.setOnClickListener(mOnClickListener);
		}
	}
	
	private void bindMainMenu() {
		//隐藏3级导航菜单
		BaseGuestUiMenu.startAnimationOUT(level3, 500, 0);
		//隐藏2级导航菜单
		BaseGuestUiMenu.startAnimationOUT(level2, 500, 500);
		isLevel3Show = !isLevel3Show;
		isLevel2Show = !isLevel2Show;
	}
	
	private void bindMainTab () {
	
		ImageButton home = (ImageButton) findViewById(R.id.home);
		ImageButton menu = (ImageButton) findViewById(R.id.menu);
		ImageButton mypage = (ImageButton) findViewById(R.id.mypage);
		ImageButton search = (ImageButton) findViewById(R.id.search);
		ImageButton bTabNews1 = (ImageButton) findViewById(R.id.c1);
		ImageButton bTabNews2 = (ImageButton) findViewById(R.id.c2);
		ImageButton bTabNews3 = (ImageButton) findViewById(R.id.c3);
		ImageButton bTabNews4 = (ImageButton) findViewById(R.id.c4);
		ImageButton bTabNews5 = (ImageButton) findViewById(R.id.c5);
		ImageButton bTabNews6 = (ImageButton) findViewById(R.id.c6);
		ImageButton bTabNews7 = (ImageButton) findViewById(R.id.c7);
		
		level2 = (RelativeLayout) findViewById(R.id.level2);
		level3 = (RelativeLayout) findViewById(R.id.level3);
	
		if (bTabNews1 != null && bTabNews2 != null && bTabNews3 != null && bTabNews4 != null && 
				bTabNews5  != null && bTabNews6 != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.search:
							doLogout(); 
							forward(UiGuestZixunList.class);
							break;
						case R.id.mypage:
							forward(UiMySiteCompanyMyPage.class);
							break;
						case R.id.c1:
							forward(UiTypesTwelve.class);//企业需求
							break;
						case R.id.c2:
							forward(UiTypesEleven.class);//园区需求
							break;
						case R.id.c3:
							forward(UiMySiteCompanyList.class);//企业走廊
							break;
						case R.id.c4:
							forward(UiMySiteServerList.class);//公共服务
							break;
						case R.id.c5:
							forward(UiCustomerList.class);//费用管理
							break;
						case R.id.c6:
							forward(UiMoveOaManagement.class);//在线场地
							break;
						case R.id.c7:
							forward(UiFashionMeet.class);//会议预定
							break;
					}
				}
			};
			
			mypage.setOnClickListener(mOnClickListener);
			search.setOnClickListener(mOnClickListener);
			
			bTabNews1.setOnClickListener(mOnClickListener);
			bTabNews2.setOnClickListener(mOnClickListener);
			bTabNews3.setOnClickListener(mOnClickListener);
			bTabNews4.setOnClickListener(mOnClickListener);
			bTabNews5.setOnClickListener(mOnClickListener);
			bTabNews6.setOnClickListener(mOnClickListener);
			bTabNews7.setOnClickListener(mOnClickListener);
		}
		
		menu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isLevel3Show){
					//隐藏3级导航菜单
					BaseGuestUiMenu.startAnimationOUT(level3, 500, 0);
				}else {
					//显示3级导航菜单
					BaseGuestUiMenu.startAnimationIN(level3, 500);
				}
				isLevel3Show = !isLevel3Show;
			}
		});
		
		home.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(!isLevel2Show){
					//显示2级导航菜单
					BaseGuestUiMenu.startAnimationIN(level2, 500);
				} else {
					if(isLevel3Show){
						//隐藏3级导航菜单
						BaseGuestUiMenu.startAnimationOUT(level3, 500, 0);
						//隐藏2级导航菜单
						BaseGuestUiMenu.startAnimationOUT(level2, 500, 500);
						isLevel3Show = !isLevel3Show;
					}
					else {
						//隐藏2级导航菜单
						BaseGuestUiMenu.startAnimationOUT(level2, 500, 0);
					}
				}
				isLevel2Show = !isLevel2Show;
			}
		});
	}
	
	//左侧滑动菜单
	private void bindMainLeft () {
		Button btn=(Button)findViewById(R.id.btn);
		if (btn != null) {
		OnClickListener mOnClickListener = new OnClickListener() {
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.btn:
							doEditNews();
							break;
					}
				}
			};
			btn.setOnClickListener(mOnClickListener);
		}
	}
}
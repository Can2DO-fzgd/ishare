﻿package com.can2do.incubation.sqlite;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatabaseHelper extends SQLiteOpenHelper {
	final String CREATE_TABLE_SQL=
		"create table phone_tb(_id integer primary " +
		"key autoincrement,name,phone,type,keyword)";
	public MyDatabaseHelper(Context context, String name,
			CursorFactory factory, int version) {
		super(context, name, factory, version);		
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_TABLE_SQL);
		init(db);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, 
			int newVersion) {
		System.out.println("---------"+oldVersion+"------->"+newVersion);
	}
	public void init(SQLiteDatabase db){
		db.execSQL("insert into phone_tb values (null,'陈津 ','58854768','综合管理部','陈津 58854768')");
		db.execSQL("insert into phone_tb values (null,'秦超 ','66000609','事业发展部','秦超66000609')");
		db.execSQL("insert into phone_tb values (null,'戴方明 ','66000605','投资促进部（国际合作部）','戴方明66000605')");
		db.execSQL("insert into phone_tb values (null,'张华 ','6000629','孵化服务部','张华6000629')");
		db.execSQL("insert into phone_tb values (null,'郑斯彦 ','66000615','总经理','郑斯彦66000615')");
		db.execSQL("insert into phone_tb values (null,'华慧 ','66000617','副总经理','华慧66000617')");       
	}
}
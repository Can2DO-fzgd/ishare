package com.can2do.incubation.sqlite;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;

import com.can2do.incubation.base.BaseSqlite;
import com.can2do.incubation.model.Zixun;

public class NewsSqlite extends BaseSqlite {

	public NewsSqlite(Context context) {
		super(context);
	}

	@Override
	protected String tableName() {
		return "zjgxtb";
	}

	@Override
	protected String[] tableColumns() {
		String[] columns = {
			Zixun.COL_ID,
			Zixun.COL_FACE,
			Zixun.COL_NAME,
			Zixun.COL_CONTENT,
			Zixun.COL_COMMENT,
			Zixun.COL_AUTHOR,
			Zixun.COL_UPTIME
		};
		return columns;
	}

	@Override
	protected String createSql() {
		return "CREATE TABLE " + tableName() + " (" +
			Zixun.COL_ID + " INTEGER PRIMARY KEY, " +
			Zixun.COL_FACE + " TEXT, " +
			Zixun.COL_NAME + " TEXT, " +
			Zixun.COL_CONTENT + " TEXT, " +
			Zixun.COL_COMMENT + " TEXT, " +
			Zixun.COL_AUTHOR + " TEXT, " +
			Zixun.COL_UPTIME + " TEXT" +
			");";
	}

	@Override
	protected String upgradeSql() {
		return "DROP TABLE IF EXISTS " + tableName();
	}

	public boolean updateNews (Zixun news) {
		// prepare News data
		ContentValues values = new ContentValues();
		values.put(Zixun.COL_ID, news.getId());
		values.put(Zixun.COL_FACE, news.getFace());
		values.put(Zixun.COL_NAME, news.getName());
		values.put(Zixun.COL_CONTENT, news.getContent());
		values.put(Zixun.COL_COMMENT, news.getComment());
		values.put(Zixun.COL_AUTHOR, news.getAuthor());
		values.put(Zixun.COL_UPTIME, news.getUptime());
		// prepare sql
		String whereSql = Zixun.COL_ID + "=?";
		String[] whereParams = new String[]{news.getId()};
		// create or update
		try {
			if (this.exists(whereSql, whereParams)) {
				this.update(values, whereSql, whereParams);
			} else {
				this.create(values);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	public ArrayList<Zixun> getAllNews () {
		ArrayList<Zixun> newsList = new ArrayList<Zixun>();
		try {
			ArrayList<ArrayList<String>> rList = this.query(null, null);
			int rCount = rList.size();
			for (int i = 0; i < rCount; i++) {
				ArrayList<String> rRow = rList.get(i);
				Zixun news = new Zixun();
				news.setId(rRow.get(0));
				news.setFace(rRow.get(1));
				news.setName(rRow.get(2));
				news.setContent(rRow.get(3));
				news.setComment(rRow.get(4));
				news.setAuthor(rRow.get(5));
				news.setUptime(rRow.get(6));
				newsList.add(news);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newsList;
	}
}
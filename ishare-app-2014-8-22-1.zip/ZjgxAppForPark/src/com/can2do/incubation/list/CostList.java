package com.can2do.incubation.list;

import java.util.ArrayList;

import com.can2do.incubation.base.BaseList;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.model.Cost;
import com.can2do.incubation.util.AppFilter;
import com.can2do.ishare.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class CostList extends BaseList {

	private BaseUi ui;
	private LayoutInflater inflater;
	private ArrayList<Cost> costList;
	
	public final class CostListItem {
		public ImageView face;
		public TextView sign;
		public TextView feetype;
		public TextView fdate;
		public TextView fee;
		public TextView jf;
		public TextView uptime;
	}
	
	public CostList (BaseUi ui, ArrayList<Cost> costList) {
		this.ui = ui;
		this.inflater = LayoutInflater.from(this.ui);
		this.costList = costList;
	}
	
	@Override
	public int getCount() {
		return costList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int p, View v, ViewGroup parent) {
		
		// init tpl
		CostListItem  costItem = null;
		
		// if cached expired
		if (v == null) {
			v = inflater.inflate(R.layout.tpl_list_cost, null);
			costItem = new CostListItem();
			costItem.fee = (TextView) v.findViewById(R.id.tpl_list_cost_text_fee);
			costItem.fdate = (TextView) v.findViewById(R.id.tpl_list_cost_text_fdate);
			costItem.uptime = (TextView) v.findViewById(R.id.tpl_list_cost_text_uptime);
			v.setTag(costItem);
		} else {
			costItem = (CostListItem) v.getTag();
		}
		
		// fill data
		costItem.uptime.setText(costList.get(p).getUptime());
		
		// fill html data
		costItem.fee.setText(AppFilter.getHtml(costList.get(p).getFee()));
		costItem.fdate.setText(AppFilter.getHtml(costList.get(p).getFdate()));
		return v;
	}
}
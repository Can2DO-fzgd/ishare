package com.can2do.incubation.list;

import java.util.ArrayList;

import com.can2do.incubation.base.BaseList;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.model.Customer1;
import com.can2do.incubation.util.AppFilter;
import com.can2do.ishare.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class Customer1List extends BaseList {

	private BaseUi ui;
	private LayoutInflater inflater;
	private ArrayList<Customer1> customerList;
	
	public final class CustomerListItem {
		public ImageView face;
		public TextView sign;
		public TextView uptime;
		public TextView username;
	}
	
	public Customer1List (BaseUi ui, ArrayList<Customer1> customerList) {
		this.ui = ui;
		this.inflater = LayoutInflater.from(this.ui);
		this.customerList = customerList;
	}
	
	@Override
	public int getCount() {
		return customerList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int p, View v, ViewGroup parent) {
		
		// init tpl
		CustomerListItem  customerItem = null;
		
		// if cached expired
		if (v == null) {
			v = inflater.inflate(R.layout.tpl_list_customer, null);
			customerItem = new CustomerListItem();
			customerItem.sign = (TextView) v.findViewById(R.id.tpl_list_news_text_content);
			customerItem.uptime = (TextView) v.findViewById(R.id.tpl_list_news_text_uptime);
			customerItem.username = (TextView) v.findViewById(R.id.tpl_list_news_text_comment);
			v.setTag(customerItem);
		} else {
			customerItem = (CustomerListItem) v.getTag();
		}
		
		// fill data
		customerItem.uptime.setText(customerList.get(p).getUptime());
		
		// fill html data
		customerItem.sign.setText(AppFilter.getHtml(customerList.get(p).getSign()));
		customerItem.username.setText(AppFilter.getHtml(customerList.get(p).getUsername()));
		return v;
	}
}
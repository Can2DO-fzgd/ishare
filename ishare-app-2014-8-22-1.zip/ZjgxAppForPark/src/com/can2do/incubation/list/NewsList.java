package com.can2do.incubation.list;

import java.util.ArrayList;

import com.can2do.incubation.base.BaseList;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.model.Zixun;
import com.can2do.incubation.util.AppCache;
import com.can2do.incubation.util.AppFilter;
import com.can2do.ishare.R;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class NewsList extends BaseList {

	private BaseUi ui;
	private LayoutInflater inflater;
	private ArrayList<Zixun> newsList;
	
	public final class NewsListItem {
		public ImageView face;
		public TextView content;
		public TextView uptime;
		public TextView comment;
	}
	
	public NewsList (BaseUi ui, ArrayList<Zixun> newsList) {
		this.ui = ui;
		this.inflater = LayoutInflater.from(this.ui);
		this.newsList = newsList;
	}
	
	@Override
	public int getCount() {
		return newsList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int p, View v, ViewGroup parent) {
		// init tpl
		NewsListItem  newsItem = null;
		// if cached expired
		if (v == null) {
			v = inflater.inflate(R.layout.tpl_list_news, null);
			newsItem = new NewsListItem();
			newsItem.face = (ImageView) v.findViewById(R.id.tpl_list_news_image_face);
			newsItem.content = (TextView) v.findViewById(R.id.tpl_list_news_text_content);
			newsItem.uptime = (TextView) v.findViewById(R.id.tpl_list_news_text_uptime);
			newsItem.comment = (TextView) v.findViewById(R.id.tpl_list_news_text_comment);
			v.setTag(newsItem);
		} else {
			newsItem = (NewsListItem) v.getTag();
		}
		// fill data
		newsItem.uptime.setText(newsList.get(p).getUptime());
		// fill html data
		newsItem.content.setText(AppFilter.getHtml(newsList.get(p).getContent()));
		newsItem.comment.setText(AppFilter.getHtml(newsList.get(p).getComment()));
		// load face image
		String faceUrl = newsList.get(p).getFace();
		Bitmap faceImage = AppCache.getImage(faceUrl);
		if (faceImage != null) {
			newsItem.face.setImageBitmap(faceImage);
		}
		return v;
	}
}
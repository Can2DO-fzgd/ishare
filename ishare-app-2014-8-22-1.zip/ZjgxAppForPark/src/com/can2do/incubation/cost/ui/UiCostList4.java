package com.can2do.incubation.cost.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;

import com.can2do.incubation.base.BaseHandler;
import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.incubation.list.CostList;
import com.can2do.incubation.model.Cost;
import com.can2do.ishare.R;

public class UiCostList4 extends BaseUiAuth{
	private ListView costListView;
	private CostList costListAdapter;

	private String memId = null;
	private String sign = null;
	private String mphone = null;
	private String feetype = null;
	private String jf = null;
	private String fdate = null;
	private String tag1 = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cost_list);
		//SysApplication.getInstance().addActivity(this);
		// set handler
		this.setHandler(new IndexHandler(this));
		
		// get params
		Bundle params = this.getIntent().getExtras();
		memId = params.getString("memId");
		sign = params.getString("sign");
		mphone = params.getString("mphone");
		feetype = params.getString("feetype");
		jf = params.getString("jf");
		fdate = params.getString("fdate");
		tag1 = params.getString("tag1");
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);	
	}
	
	@Override
	public void onStart(){
		super.onStart();
		
		// show all news list
		HashMap<String, String> costParams = new HashMap<String, String>();
		costParams.put("memid", memId);
		costParams.put("typeId", "4");//0：按企业Id查，1：按费用类别查，2：按费用时间查，3：按费用类别和费用时间查4：按费用类别，费用时间和缴费情况查，5：按费用类别和缴费情况查
		costParams.put("pageId", "1");
		costParams.put("pageCount", "10");
		costParams.put("feetype", feetype);//1：房租，2：水费，3：电费，4：物业费
		costParams.put("fdate", fdate);
		costParams.put("jf",jf);
		this.doTaskAsync(C.task.costTypesList, C.api.costTypesList, costParams);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
			case C.task.costTypesList:
				try {
					@SuppressWarnings("unchecked")
					final ArrayList<Cost> costList = (ArrayList<Cost>) message.getResultList("Cost");
					// load face image
					for (Cost news : costList) {
						loadImage(news.getFace());
						//newsSqlite.updateNews(news);
					}
					// show text
					costListView = (ListView) this.findViewById(R.id.app_index_list_view);
					costListAdapter = new CostList(this, costList);
					costListView.setAdapter(costListAdapter);
					costListView.setOnItemClickListener(new OnItemClickListener(){
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
							Bundle params = new Bundle();
						
							params.putString("costId", costList.get(pos).getId());
							params.putString("feetype", costList.get(pos).getFeetype());
							params.putString("fdate", costList.get(pos).getFdate());
							params.putString("fee", costList.get(pos).getFee());
							params.putString("jf", costList.get(pos).getJf());
							params.putString("tag1", tag1);
							params.putString("sign", sign);
							params.putString("mphone", mphone);
							overlay(UiCost.class, params);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
		}
	}
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
		toast(C.err.network);
		switch (taskId) {
			case C.task.costTypesList:
				break;
		}
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			doFinish();
		}
		return super.onKeyDown(keyCode, event);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes
	
	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
						costListAdapter.notifyDataSetChanged();
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}
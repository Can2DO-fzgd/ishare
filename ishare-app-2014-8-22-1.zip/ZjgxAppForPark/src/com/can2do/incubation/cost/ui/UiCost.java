package com.can2do.incubation.cost.ui;

import java.util.HashMap;
import android.net.Uri; 

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.can2do.incubation.base.BaseHandler;
import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.incubation.model.Cost;
import com.can2do.incubation.model.Customer;
import com.can2do.incubation.util.AppCache;
import com.can2do.incubation.util.AppFilter;
import com.can2do.incubation.util.UIUtil;
import com.can2do.ishare.R;
//import com.zjgx.app.ui.SysApplication;

public class UiCost extends BaseUiAuth {

	private String costId = null;
	private String feetype = null;
	private String fdate = null;
	private String fee = null;
	private String jf = null;
	private String tag1 = null;
	private String sign = null;
	private String mphone = null;
	private String phone = null;
	private String tell = null;
	private String phone1 = null;
	
	private String newspathurl;
	private String customerId = null;
	private Button addfansBtn = null;
	private ImageView faceImage = null;
	private String faceImageUrl = null;

	View myView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_cost);
		//SysApplication.getInstance().addActivity(this);
		// set handler
		this.setHandler(new NewsHandler(this));

		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);
		
		LayoutInflater factory = LayoutInflater.from(this);
		myView = factory.inflate(R.layout.phonetrue, null);// 获取布局文件；
		
		// get params
		Bundle params = this.getIntent().getExtras();
		costId = params.getString("costId");
		feetype = params.getString("feetype");
		fdate = params.getString("fdate");
		fee = params.getString("fee");
		jf = params.getString("jf");
		tag1 = params.getString("tag1");
		sign = params.getString("sign");
		mphone = params.getString("mphone");
		
		newspathurl = "紫金高新缴费通知! " 
				+ "\n尊敬的园区用户【" + sign
				+ "】您好！您" + fdate
				+ "还有" + tag1 + fee
				+ "元还未缴纳，请你及时缴纳！谢谢！" 
				+ "\n【官网网址】： http://www.can2do.com/platform/zjgx/"
				+ "   移动APP下载请点击链接下载！"
				+ "\nhttp://www.can2do.com/platform/zjgx/front/mobile/index.html";

		phone = "smsto:" + mphone;
		tell = "tel:" + mphone;
		
		// do add fans
		addfansBtn = (Button) this.findViewById(R.id.app_news_btn_addfans);
		addfansBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// prepare news data
				HashMap<String, String> urlParams = new HashMap<String, String>();
				urlParams.put("customerId", customerId);
				urlParams.put("message", "有人关注你了！");
				doTaskAsync(C.task.fansAdd1, C.api.fansAdd1, urlParams);
			}
		});

		OnClickListener mOnClickListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.app_news_btn_share:
					Share();
					break;
				case R.id.app_cost_btn_notice:
					Notice();
					break;
				case R.id.app_cost_btn_notice1:
					new AlertDialog.Builder(UiCost.this).setView(
						      myView).setTitle("安全 提示").setMessage(
						      "请核对你所拨打的号码否正确！").setIcon(
						      R.drawable.icon).setPositiveButton("确定",
						      new DialogInterface.OnClickListener() {
						       @Override
							public void onClick(DialogInterface dialog,
						         int whichButton) {
						        setResult(RESULT_OK);
						        Notice1();
						        finish();
						       }
						      }).setNegativeButton("取消",
						      new DialogInterface.OnClickListener() {
						       @Override
							public void onClick(DialogInterface dialog,
						         int whichButton) {
						    	   finish();
						       }
						      }).show();
					break;
				}
			}
		};
		findViewById(R.id.app_news_btn_share).setOnClickListener(
				mOnClickListener);
		findViewById(R.id.app_cost_btn_notice).setOnClickListener(
				mOnClickListener);
		findViewById(R.id.app_cost_btn_notice1).setOnClickListener(
				mOnClickListener);
		// prepare news data
		HashMap<String, String> costParams = new HashMap<String, String>();
		costParams.put("costId" ,costId);
		this.doTaskAsync(C.task.costView, C.api.costView, costParams);
	}

	// 分享平台通知缴费提醒
	protected void Share() {
		Intent intent = new Intent(Intent.ACTION_SEND);

		intent.setType("image/*");

		intent.putExtra(Intent.EXTRA_SUBJECT, "高新移动园区缴费提醒！");
				
		intent.putExtra(Intent.EXTRA_TEXT,newspathurl);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(Intent.createChooser(intent, getTitle()));

	}

	// 通过短信发缴费提醒
	protected void Notice() {
		Intent in4 = new Intent();  
        in4.setAction(Intent.ACTION_SENDTO);  
        in4.setData(Uri.parse(phone));  
        in4.putExtra("sms_body", newspathurl);  
        startActivity(in4); 
	}
	
	// 通过打电话通知缴费
	protected void Notice1() {
		Intent in2 = new Intent();  
        in2.setAction(Intent.ACTION_CALL);  
        in2.setData(Uri.parse(tell));  
        startActivity(in2);  
	}
	 
	// //////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods

	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
		case C.task.costView:
			try {
				Cost cost = (Cost) message.getResult("Cost");
				TextView textUptime = (TextView) this
						.findViewById(R.id.app_news_text_uptime);
				TextView textTitle = (TextView) this
						.findViewById(R.id.app_news_text_title);
				TextView textContent = (TextView) this
						.findViewById(R.id.app_news_text_content);
				textUptime.setText(cost.getUptime());
				textTitle.setText(AppFilter.getHtml(cost.getFee()));
				textContent.setText(AppFilter.getHtml(cost.getFdate()));
				Customer customer = (Customer) message.getResult("Customer");
				TextView textCustomerName = (TextView) this
						.findViewById(R.id.app_news_text_customer_name);
				TextView testCustomerInfo = (TextView) this
						.findViewById(R.id.app_news_text_customer_info);
				TextView testCostTypeInfo = (TextView) this
						.findViewById(R.id.app_cost_type_title);
				textCustomerName.setText(customer.getSign());
				testCustomerInfo
						.setText(UIUtil.getCustomer1Info(this, customer));
				testCostTypeInfo.setText(tag1);
				// set customer id
				customerId = customer.getId();
				// load face image async
				faceImage = (ImageView) this
						.findViewById(R.id.app_news_image_face);
				faceImageUrl = customer.getFaceurl();
				loadImage(faceImageUrl);
			} catch (Exception e) {
				e.printStackTrace();
				toast(e.getMessage());
			}
			break;
		case C.task.fansAdd1:
			if (message.getCode().equals("10000")) {
				toast("关注成功！");
				// refresh customer data
				HashMap<String, String> cvParams = new HashMap<String, String>();
				cvParams.put("customerId", customerId);
				this.doTaskAsync(C.task.customer1View, C.api.customer1View,cvParams);
			} else {
				toast("关注失败！可能你已经关注了他");
			}
			break;
		case C.task.customer1View:
			try {
				// update customer info
				final Customer customer = (Customer) message
						.getResult("Customer");
				TextView textInfo = (TextView) this
						.findViewById(R.id.app_news_text_customer_info);
				textInfo.setText(UIUtil.getCustomer1Info(this, customer));
			} catch (Exception e) {
				e.printStackTrace();
				toast(e.getMessage());
			}
			break;
		}
	}

	@Override
	public void onNetworkError(int taskId) {
		super.onNetworkError(taskId);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// other methods

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			doFinish();
		}
		return super.onKeyDown(keyCode, event);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes


	@SuppressLint("HandlerLeak")
	private class NewsHandler extends BaseHandler {
		public NewsHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					Bitmap face = AppCache.getImage(faceImageUrl);
					faceImage.setImageBitmap(face);
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}
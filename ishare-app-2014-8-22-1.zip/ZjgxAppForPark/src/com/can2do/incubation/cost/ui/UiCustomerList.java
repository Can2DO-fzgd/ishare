package com.can2do.incubation.cost.ui;

import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;

import com.can2do.incubation.base.BaseHandler;
import com.can2do.incubation.base.BaseMessage;
import com.can2do.incubation.base.BaseTask;
import com.can2do.incubation.base.BaseUi;
import com.can2do.incubation.base.BaseUiAuth;
import com.can2do.incubation.base.C;
import com.can2do.incubation.list.CustomerList;
import com.can2do.incubation.model.Customer;
import com.can2do.incubation.ui.UiMoveOa;
import com.can2do.ishare.R;

public class UiCustomerList extends BaseUiAuth{
	private ListView customerListView;
	private CustomerList customerListAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customer_list);
		//SysApplication.getInstance().addActivity(this);
		// set handler
		this.setHandler(new IndexHandler(this));
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);
	}
	
	@Override
	public void onStart(){
		super.onStart();
		
		// show all cost list
		this.doTaskAsync(C.task.enterpriseList, C.api.enterpriseList);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
			case C.task.enterpriseList:
				try {
					@SuppressWarnings("unchecked")
					final ArrayList<Customer> customerList = (ArrayList<Customer>) message.getResultList("Customer");
					// load face image
					for (Customer news : customerList) {
						loadImage(news.getFace());
					}
					// show text
					customerListView = (ListView) this.findViewById(R.id.app_index_list_view);
					customerListAdapter = new CustomerList(this, customerList);
					customerListView.setAdapter(customerListAdapter);
					customerListView.setOnItemClickListener(new OnItemClickListener(){
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
							Bundle params = new Bundle();
							params.putString("memId", customerList.get(pos).getId());
							params.putString("sign", customerList.get(pos).getSign());
							params.putString("mphone", customerList.get(pos).getMphone());
							overlay(UiCostTypeList.class, params);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
		}
	}
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
		toast(C.err.network);
		switch (taskId) {
			case C.task.enterpriseList:

				break;
		}
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiMoveOa.class);
		}
		return super.onKeyDown(keyCode, event);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes
	
	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
					case BaseTask.LOAD_IMAGE:
						customerListAdapter.notifyDataSetChanged();
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}
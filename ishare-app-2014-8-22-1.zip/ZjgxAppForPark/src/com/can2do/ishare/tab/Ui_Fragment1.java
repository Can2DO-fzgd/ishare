package com.can2do.ishare.tab;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.can2do.ishare.R;
import com.can2do.ishare.jquery.Indexhtml1;
import com.can2do.ishare.jquery.Indexhtml2;
import com.can2do.ishare.base.GuestC;

public class Ui_Fragment1 extends Fragment {

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		
//        this.getView().findViewById(R.id.clickme).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Ui_Main activity = ((Ui_Main)getActivity());
//                EditText editText = (EditText) activity.mFragment1.getView().findViewById(R.id.edit);
//                Toast.makeText(activity, editText.getText(), Toast.LENGTH_SHORT).show();
//                
//            }
//        });
        
        this.getView().findViewById(R.id.product_btn1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product1);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product1), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product2);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product2), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product3);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product3), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product4);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product4), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product5);
                startActivity(in);
               // Toast.makeText(activity, Resources.getSystem().getString(R.string.product5), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product6);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product6), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product7);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product7), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product8);
                startActivity(in);
                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product8), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product9);
                startActivity(in);
               // Toast.makeText(activity, Resources.getSystem().getString(R.string.product9), Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.product_btn10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ui_Main activity = ((Ui_Main)getActivity());
                Intent in=new Intent(getActivity(),Indexhtml1.class);
                in.putExtra("url", GuestC.web.product10);
                startActivity(in);
               // Toast.makeText(activity, Resources.getSystem().getString(R.string.product10), Toast.LENGTH_SHORT).show();
            }
        });
        
//        this.getView().findViewById(R.id.product_btn11).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Ui_Main activity = ((Ui_Main)getActivity());
//                Intent in=new Intent(getActivity(),Indexhtml1.class);
//                in.putExtra("url", GuestC.web.product11);
//                startActivity(in);
//                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product11), Toast.LENGTH_SHORT).show();
//            }
//        });
        
//        this.getView().findViewById(R.id.product_btn12).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Ui_Main activity = ((Ui_Main)getActivity());
//                Intent in=new Intent(getActivity(),Indexhtml1.class);
//                in.putExtra("url", GuestC.web.product12);
//                startActivity(in);
//                //Toast.makeText(activity, Resources.getSystem().getString(R.string.product12), Toast.LENGTH_SHORT).show();
//            }
//        });
        
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflateAndSetupView(inflater, container, savedInstanceState, R.layout.ui_tab_fragment1);	
	}
	
	private View inflateAndSetupView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState, int layoutResourceId) {
		View layout = inflater.inflate(layoutResourceId, container, false);
		return layout;
	} 
}

package com.can2do.ishare.locus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.can2do.ishare.R;
import com.can2do.ishare.locus.LocusPassWordView.OnCompleteListener;
import com.can2do.ishare.locus.util.StringUtil;
import com.can2do.ishare.tab.Ui_Main;

public class SetPasswordActivity extends Activity {
	private LocusPassWordView lpwv;
	private String password;
	private boolean needverify = true;
	private Toast toast;

	private void showToast(CharSequence message) {
		if (null == toast) {
			toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
//			toast.setGravity(Gravity.CENTER, 0, 0);
		} else {
			toast.setText(message);
		}

		toast.show();
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setpassword_activity);
		
		TextView toastTv = (TextView) findViewById(R.id.login_toast1);
		toastTv.setText("请输入手势密码完成密码设置或修改！");
		toastTv.setTextSize(18);
		
		lpwv = (LocusPassWordView) this.findViewById(R.id.mLocusPassWordView);
		lpwv.setOnCompleteListener(new OnCompleteListener() {
			
			@Override
			public void onComplete(String mPassword) {
				password = mPassword;
				if (needverify) {
					if (lpwv.verifyPassword(mPassword)) {
						showToast("密码输入正确,请输入新密码!");
						lpwv.clearPassword();
						needverify = false;
					} else {
						showToast("原始密码输入错误,请重新输入!");
						lpwv.clearPassword();
						password = "";
					}
				}
			}
		});

		OnClickListener mOnClickListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.tvSave:
					if (StringUtil.isNotEmpty(password)) {
						lpwv.resetPassWord(password);
						lpwv.clearPassword();
						showToast("密码修改成功,请记住密码.");
						startActivity(new Intent(SetPasswordActivity.this,
								LoginActivity.class));
						finish();
					} else {
						lpwv.clearPassword();
						showToast("密码不能为空,请输入密码.");
					}
					break;
				case R.id.tvReset:
					lpwv.clearPassword();
					break;
				case R.id.tvClose:
					if (lpwv.isPasswordEmpty()) {
						showToast("亲，你还未设置手势密码哦！");
					} else {
					if (StringUtil.isNotEmpty(password)) {
					lpwv.resetPassWord("");
					lpwv.clearPassword();
					showToast("关闭手势密码成功！");
					startActivity(new Intent(SetPasswordActivity.this,
							Ui_Main.class));
					finish();
					} else {
						lpwv.clearPassword();
						showToast("请输入现在的密码,以确认关闭手势密码功能.");
					}
					}
					break;
				}
			}
		};
		Button buttonSave = (Button) this.findViewById(R.id.tvSave);
		buttonSave.setOnClickListener(mOnClickListener);
		Button tvReset = (Button) this.findViewById(R.id.tvReset);
		tvReset.setOnClickListener(mOnClickListener);
		Button tvClose = (Button) this.findViewById(R.id.tvClose);
		tvClose.setOnClickListener(mOnClickListener);
		// 如果密码为空,直接输入密码
		if (lpwv.isPasswordEmpty()) {
			this.needverify = false;
			showToast("请输入密码");
		}
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

}
